package cn.tedu.shoot;
/** 小敌机 */
public class Airplane {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度

    /** 移动 */
    void step(){
        System.out.println("小敌机的y向下移动");
    }
}


















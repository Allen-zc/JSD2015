package cn.tedu.shoot;
/** 天空 */
public class Sky {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度
    int y1; //第2张天空图的y坐标

    /** 移动 */
    void step(){
        System.out.println("天空的y和y1同时向下移动");
    }
}



















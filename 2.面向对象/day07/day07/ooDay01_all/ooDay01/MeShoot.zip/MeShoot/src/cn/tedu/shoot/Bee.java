package cn.tedu.shoot;
/** 小蜜蜂 */
public class Bee {
    int width;
    int height;
    int x;
    int y;
    int xSpeed;    //x坐标移动速度
    int ySpeed;    //y坐标移动速度
    int awardType; //奖励类型

    /** 移动 */
    void step(){
        System.out.println("小蜜蜂的x左右移动、y向下移动");
    }
}



















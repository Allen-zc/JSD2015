package cn.tedu.shoot;
/** 大敌机 */
public class BigAirplane {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度

    /** 移动 */
    void step(){
        System.out.println("大敌机的y向下移动");
    }
}




















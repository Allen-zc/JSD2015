package cn.tedu.shoot;
/** 整个游戏窗口 */
public class World {
    Sky s;
    Hero h;
    Airplane a1;
    Airplane a2;
    BigAirplane ba1;
    BigAirplane ba2;
    Bee b1;
    Bee b2;
    Bullet bt1;
    Bullet bt2;

    void action(){ //测试代码
        s = new Sky();
        s.width = 400;
        s.height = 700;
        s.x = 0;
        s.y = 0;
        s.speed = 1;
        s.y1 = -700;
        s.step();

        h = new Hero();
        h.width = 40;
        h.height = 50;
        h.x = 130;
        h.y = 200;
        h.life = 3;
        h.fire = 0;
        h.step();

        a1 = new Airplane();
        a1.width = 30;
        a1.height = 40;
        a1.x = 100;
        a1.y = 200;
        a1.speed = 2;
        a1.step();

        a2 = new Airplane();
        a2.width = 30;
        a2.height = 40;
        a2.x = 180;
        a2.y = 300;
        a2.speed = 2;
        a2.step();

    }

    public static void main(String[] args) {
        World w = new World();
        w.action();
    }
}

/*
 1.问:为何将那一堆引用设计在main的外面?
   答:若将引用设计在main中，意味着这堆引用就只能在main中访问了
      而实际情况下，World类中会包含很多方法，这些方法都需要用到这堆引用，
      所以设计在main的外面来扩大作用范围
 2.问:为何要单独创建action方法来测试?
   答:因为main是static的，在static的方法中无法访问那一堆引用
     所以单独创建非static的方法action来进行测试
     ----关于static，面向对象第5天详细讲解
 3.问:为何在main中要先创建World对象，再通过引用调用action方法?
   答:因为main是static的，在static的方法中无法直接调用action方法
     所以先创建World类对象，再通过引用调用action方法
     ----关于static，面向对象第5天详细讲解
*/




















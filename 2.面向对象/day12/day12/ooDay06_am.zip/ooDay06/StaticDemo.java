package oo.day06;
//static的演示
public class StaticDemo {
    public static void main(String[] args) {
        /*
        Aoo o1 = new Aoo();
        o1.show();
        Aoo o2 = new Aoo();
        o2.show();
        Aoo o3 = new Aoo();
        o3.show();
        System.out.println(Noo.b); //常常通过类名点来访问
         */

        //Coo.test(5,6);

        Doo o4 = new Doo();
        Doo o5 = new Doo();
        Doo o6 = new Doo();

    }
}

//演示静态块
class Doo{
    static {
        System.out.println("静态块");
    }
    Doo(){
        System.out.println("构造方法");
    }
}









//演示静态方法
class Coo{
    int a;
    void show(){ //需要访问对象的数据a，意味着与对象有关，所以不适用做成静态方法
        a++;
    }
    static void test(int num1,int num2){ //不需要访问对象的数据，意味着与对象无关
        int num = num1+num2;      //更适合做成静态方法
        System.out.println(num);
    }
}
//演示静态方法
class Boo{
    int a;        //实例变量(对象点)
    static int b; //静态变量(类名点)

    void show(){ //有个隐式this传递
        System.out.println(this.a);
        System.out.println(Boo.b);
    }
    static void test(){ //没有隐式this传递
        //静态方法中没有隐式的this传递
        //没有this就意味着没有对象
        //而实例变量a必须通过对象点来访问
        //所以如下语句编译错误
        //System.out.println(a); //编译错误
        System.out.println(Boo.b);
    }
}


//演示静态变量
class Aoo{
    int a;        //实例变量
    static int b; //静态变量
    Aoo(){
        a++;
        b++;
    }
    void show(){
        System.out.println("a="+a+"，b="+b);
    }
}





















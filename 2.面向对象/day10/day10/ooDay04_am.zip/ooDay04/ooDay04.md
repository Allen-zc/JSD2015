### 射击游戏第一天：

1. 设计6个类，设计World类并测试

### 射击游戏第二天：

1. 给6个类添加构造方法，并测试

### 射击游戏第三天：

1. 设计小敌机数组、大敌机数组、小蜜蜂数组、子弹数组，并测试
2. 设计FlyingObject超类，6个派生类继承超类
3. 在FlyingObject中设计两个构造方法，6个派生类分别调用

### 射击游戏第四天：

1. ...
2. ...
3. 画窗口：



## 回顾：

1. 引用类型数组：

   ```java
   Student[] stus = new Student[3];
   stus[0] = new Student("zhangsan",25,"LF");
   System.out.println(stus[0].name);
   for(int i=0;i<stus.length;i++){
       System.out.println(stus[i].name);
       stus[i].sayHi();
   }
   ```

2. 继承：

      代码复用，extends，超类:共有的   派生类:特有的   派生类可以访问: 派生类+超类   超类不能访问派生类的

      单一继承、传递性   构造派生类之前必须先构造超类

      派生类构造中若不调用超类构造，则默认super()调超类无参构造，若自己调了则不再默认提供

3. super：指代当前对象的超类对象

   super.成员变量名------------------------------访问超类的成员变量

   super.方法名()-----------------------------------调用超类的方法----------------------下午讲

   super()---------------------------------------------调用超类的构造方法





## 正课:

1. 向上造型：
   - 超类型的引用指向派生类的对象
   - 能点出来什么，看引用的类型-----------------这是规定，记住就可以了
2. 方法的重写：
3. 重写与重载的区别：





```java
for(int i=0;i<bullets.length;i++){ //遍历所有子弹
    Bullet b = bullets[i]; //获取每一个子弹
    System.out.println(b.x+","+b.y);
}
```

























Teacher对象



Student对象



人

















Aoo

Boo-----继承Aoo















```java
 超类          派生类
Animal o3 = new Tiger();
o3. 只能点出Animal类中的

Person p1 = new Student();
Person p2 = new Teacher();
Person p3 = new Doctor();
p1/p2/p3. 只能点出Person类中的

FlyingObject o1 = new Airplane();
FlyingObject o2 = new BigAirplane();
FlyingObject o3 = new Bee();
FlyingObject o4 = new Hero();
FlyingObject o5 = new Sky();
FlyingObject o6 = new Bullet(100,200);
o1/o2/o3/o4/o5/o6. 只能点出FlyingObject类中的


```































```java
//动物是动物
Animal o1 = new Animal();
//老虎是老虎
Tiger o2 = new Tiger();
//老虎是动物----语义通
Animal o3 = new Tiger();

//动物是老虎----语义不通
Tiger o4 = new Animal(); //编译错误

class Animal{ //动物
}
class Tiger extends Animal{ //老虎
}
```






















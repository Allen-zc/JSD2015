package oo.day04;

import javax.print.Doc;

//测试
public class Test {
    public static void main(String[] args) {
        Person[] ps = new Person[5];
        ps[0] = new Student("zhangsan",25,"LF","111");
        ps[1] = new Student("lisi",26,"JMS","222");
        ps[2] = new Teacher("wangwu",34,"SD",8000.0);
        ps[3] = new Teacher("zhaoliu",29,"SX",15000.0);
        ps[4] = new Doctor("sunqi",35,"LF","主任医师");
        for(int i=0;i<ps.length;i++){
            System.out.println(ps[i].name); //输出每个人的名字
            ps[i].sayHi(); //每个人跟大家问好
        }
    }
}

class Person{
    String name;
    int age;
    String address;
    Person(String name,int age,String address){
        this.name = name;
        this.age = age;
        this.address = address;
    }
    void sayHi(){
        System.out.println("大家好，我叫"+name+"，今年"+age+"岁了，家住"+address);
    }
}
class Student extends Person{
    String stuId; //学号
    Student(String name,int age,String address,String stuId){
        super(name,age,address);
        this.stuId = stuId;
    }
}
class Teacher extends Person{
    double salary; //工资
    Teacher(String name,int age,String address,double salary){
        super(name,age,address);
        this.salary = salary;
    }
}
class Doctor extends Person{
    String level; //职称
    Doctor(String name,int age,String address,String level){
        super(name,age,address);
        this.level = level;
    }
}
































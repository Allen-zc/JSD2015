package oo.day05_vis;
import oo.day05.Joo;
public class Loo { //演示同包
    void show(){
        Joo o = new Joo();
        o.a = 1;
        //o.b = 2; //编译错误
        //o.c = 3; //编译错误
        //o.d = 4; //编译错误
    }
}

class Moo extends Joo{ //跨包继承----演示protected
    void show(){
        a = 1;
        b = 2;
        //c = 3;  //编译错误
        //d = 4;  //编译错误
    }
}





















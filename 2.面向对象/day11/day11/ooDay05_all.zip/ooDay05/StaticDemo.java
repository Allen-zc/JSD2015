package oo.day05;
//static的演示
public class StaticDemo {
    public static void main(String[] args) {
        Noo o1 = new Noo();
        o1.show();
        Noo o2 = new Noo();
        o2.show();
        Noo o3 = new Noo();
        o3.show();
        System.out.println(Noo.b); //常常通过类名点来访问
    }
}

//演示静态变量
class Noo{
    int a;        //实例变量
    static int b; //静态变量
    Noo(){
        a++;
        b++;
    }
    void show(){
        System.out.println("a="+a+"，b="+b);
    }
}





















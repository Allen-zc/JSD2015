package oo.day05;
//final的演示
public class FinalDemo {
    public static void main(String[] args) {

    }
}

//演示final修饰类
final class Foo{}
//class Goo extends Foo{} //编译错误，final的类不能被继承
class Hoo{}
final class Ioo extends Hoo{} //不能当老爸，但能当儿子


//演示final修饰方法
class Doo{
    final void show(){}
    void test(){}
}
class Eoo extends Doo{
    //void show(){} //编译错误，final的方法不能被重写
    void test(){}
}

//演示final修饰变量
class Coo{
    final int a = 5;
    void test(){
        //a = 55; //编译错误，final的变量不能被改变
    }
}




















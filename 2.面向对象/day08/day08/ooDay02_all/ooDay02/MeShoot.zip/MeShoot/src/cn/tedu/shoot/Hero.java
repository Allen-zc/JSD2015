package cn.tedu.shoot;
/** 英雄机 */
public class Hero {
    int width;  //宽
    int height; //高
    int x;      //x坐标
    int y;      //y坐标
    int life;   //命
    int fire;   //火力值
    /** 构造方法 */
    Hero(){
        width = 97;
        height = 139;
        x = 140;
        y = 400;
        life = 3;
        fire = 0;
    }

    /** 移动 */
    void step(){
        System.out.println("英雄机切换图片啦!");
    }
}




















package cn.tedu.shoot;
import java.util.Random;
/** 小敌机 */
public class Airplane {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度
    /** 构造方法 */
    Airplane(){
        width = 48;
        height = 50;
        Random rand = new Random(); //随机数对象
        x = rand.nextInt(400-width); //0到(窗口宽-小敌机宽)之内的随机数
        y = -height; //负的小敌机的高
        speed = 2;
    }

    /** 移动 */
    void step(){
        System.out.println("小敌机的y向下移动");
    }
}


















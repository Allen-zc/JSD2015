package cn.tedu.shoot;
/** 子弹 */
public class Bullet {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度
    /** 构造方法 */
    Bullet(int x,int y){ //子弹有多个，每个子弹的初始坐标都不同，所以传参
        width = 8;
        height = 20;
        this.x = x;
        this.y = y;
        speed = 3;
    }

    /** 移动 */
    void step(){
        System.out.println("子弹的y向上移动");
    }
}
















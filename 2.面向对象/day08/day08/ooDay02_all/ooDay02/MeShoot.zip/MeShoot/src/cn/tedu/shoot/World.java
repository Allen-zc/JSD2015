package cn.tedu.shoot;
/** 整个游戏窗口 */
public class World {
    Sky s = null;
    Hero h = null;
    Airplane a1 = null;
    Airplane a2 = null;
    Airplane a3;
    Airplane a4;
    BigAirplane ba1;
    BigAirplane ba2;
    Bee b1;
    Bee b2;
    Bullet bt1;
    Bullet bt2;

    void action(){ //测试代码
        s = new Sky();
        h = new Hero();
        a1 = new Airplane();
        a2 = new Airplane();
        a3 = new Airplane();
        a4 = new Airplane();
        ba1 = new BigAirplane();
        ba2 = new BigAirplane();
        b1 = new Bee();
        b2 = new Bee();
        bt1 = new Bullet(100,200);
        bt2 = new Bullet(150,267);

        System.out.println(h.width+","+h.height+","+h.x+","+h.y+","+h.life+","+h.fire);
        System.out.println(a1.width+","+a1.height+","+a1.x+","+a1.y+","+a1.speed);
        System.out.println(a2.width+","+a2.height+","+a2.x+","+a2.y+","+a2.speed);
        System.out.println(a3.width+","+a3.height+","+a3.x+","+a3.y+","+a3.speed);
        System.out.println(a4.width+","+a4.height+","+a4.x+","+a4.y+","+a4.speed);
    }

    public static void main(String[] args) {
        World w = new World();
        w.action();
    }
}

/*
 1.问:为何将那一堆引用设计在main的外面?
   答:若将引用设计在main中，意味着这堆引用就只能在main中访问了
      而实际情况下，World类中会包含很多方法，这些方法都需要用到这堆引用，
      所以设计在main的外面来扩大作用范围
 2.问:为何要单独创建action方法来测试?
   答:因为main是static的，在static的方法中无法访问那一堆引用
     所以单独创建非static的方法action来进行测试
     ----关于static，面向对象第5天详细讲解
 3.问:为何在main中要先创建World对象，再通过引用调用action方法?
   答:因为main是static的，在static的方法中无法直接调用action方法
     所以先创建World类对象，再通过引用调用action方法
     ----关于static，面向对象第5天详细讲解
*/




















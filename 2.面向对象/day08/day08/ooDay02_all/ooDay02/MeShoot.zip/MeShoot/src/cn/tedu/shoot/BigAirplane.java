package cn.tedu.shoot;
import java.util.Random;
/** 大敌机 */
public class BigAirplane {
    int width;
    int height;
    int x;
    int y;
    int speed; //移动速度
    /** 构造方法 */
    BigAirplane(){
        width = 66;
        height = 89;
        Random rand = new Random(); //随机数对象
        x = rand.nextInt(400-width); //0到(窗口宽-大敌机宽)之内的随机数
        y = -height; //负的大敌机的高
        speed = 2;
    }

    /** 移动 */
    void step(){
        System.out.println("大敌机的y向下移动");
    }
}




















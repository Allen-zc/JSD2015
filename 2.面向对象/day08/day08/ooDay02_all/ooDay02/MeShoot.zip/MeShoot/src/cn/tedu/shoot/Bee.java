package cn.tedu.shoot;

import java.util.Random;

/** 小蜜蜂 */
public class Bee {
    int width;
    int height;
    int x;
    int y;
    int xSpeed;    //x坐标移动速度
    int ySpeed;    //y坐标移动速度
    int awardType; //奖励类型
    /** 构造方法 */
    Bee(){
        width = 60;
        height = 51;
        Random rand = new Random(); //随机数对象
        x = rand.nextInt(400-width); //0到(窗口宽-小蜜蜂宽)之内的随机数
        y = -height; //负的小蜜蜂的高
        xSpeed = 1;
        ySpeed = 2;
        awardType = rand.nextInt(2); //0到1之间的随机数
    }

    /** 移动 */
    void step(){
        System.out.println("小蜜蜂的x左右移动、y向下移动");
    }
}



















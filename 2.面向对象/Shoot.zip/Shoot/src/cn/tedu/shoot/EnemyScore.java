package cn.tedu.shoot;
/** �÷ֽӿ� */
public interface EnemyScore {
	/** �÷� */
	public int getScore();
}

















